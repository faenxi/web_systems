// Validation namespace/функції
