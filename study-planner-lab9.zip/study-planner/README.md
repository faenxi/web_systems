# Study Planner — лабораторна робота №9

React 19 + TypeScript + Vite, стилі — SCSS + BEM. Тема: Context API, `useReducer`, `useEffect`, `localStorage`, Custom Hooks.

## Запуск

```bash
npm install
npm run dev      # розробка
npm run lint     # ESLint
npm run build    # перевірка типів + збірка
```

Потрібен Node.js 22.22+.

## Де що реалізовано

| Вимога | Файл |
| --- | --- |
| `useReducer`: add, toggle, update, requestDelete, confirmDelete, undoDelete, clearCompleted, reset | `src/reducers/taskReducer.ts`, типи дій — `src/types/task.ts` |
| Context API (`TaskContext`, `TaskProvider`) | `src/context/TaskContext.ts`, `src/context/TaskProvider.tsx` |
| Custom Hook `useTaskContext()` (помилка поза провайдером) | `src/hooks/useTaskContext.ts` |
| Custom Hook `useLocalStorage<T>()` (активний фільтр) | `src/hooks/useLocalStorage.ts` |
| Збереження `tasks` у `localStorage` через `useEffect`, захист від битого JSON | `src/data/storage.ts`, `TaskProvider.tsx` (Effect 1) |
| Undoable Delete: таймер 5 с, `clearTimeout` у cleanup | `TaskProvider.tsx` (Effect 2) |
| Автозникнення Toast | `TaskProvider.tsx` (Effect 3) |
| `document.title` = «Study Planner — N active tasks» | `src/App.tsx` |
| Toast з прогресом і кнопкою «Скасувати» | `src/components/Toast.tsx` |
| Редагування (title, description, priority, category) | `src/components/TaskForm.tsx` |
| «Очистити виконані» (власний undo-flow), «Скинути дані» | `src/components/Actions.tsx` |
| Фільтри, статистика, порожній список (derived state під час render) | `FilterBar`, `Stats`, `TaskList`, `useMemo` у `TaskProvider` |

## Рішення, які варто пояснити на захисті

- Reducer чистий: `id`, `createdAt` і `token` приходять у payload, localStorage і таймери в ньому відсутні.
- `tasks` має єдине джерело правди — reducer. `localStorage` лише дзеркало; читається один раз у lazy-ініціалізації (`initTaskState`).
- Одночасно діє одне Undoable Delete: новий запит у reducer остаточно завершує попередній.
- Завдання в стані очікування видалення лишається в `tasks` (приглушене, бейдж «Буде видалено») і не враховується в статистиці та `document.title`. Якщо перезавантажити сторінку під час очікування, завдання просто повернеться — за умовою відновлювати незавершене видалення не потрібно.
- Фільтрація й статистика — derived state, обчислюється під час render, а не в `useEffect`.
- Форма редагування перемонтовується через `key` (`editingTask?.id`), тому початкові значення беруться без Effect.

## Рекомендовані коміти

```text
git switch -c feature/state-effects
feat(lab-09): add reducer, context and persistence
feat(lab-09): add undoable delete with toast
feat(lab-09): add task editing and bulk actions
docs(lab-09): add readme
```
