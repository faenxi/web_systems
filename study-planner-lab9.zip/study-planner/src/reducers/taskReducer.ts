import { initialTasks } from '../data/initialTasks';
import { loadStoredTasks } from '../data/storage';
import type { Task, TaskAction, TaskState } from '../types/task';

/**
 * Початковий стан для useReducer (lazy init): збережені завдання або початковий список.
 * Читання localStorage відбувається тут, а не всередині самого reducer.
 */
export function initTaskState(): TaskState {
  return { tasks: loadStoredTasks() ?? initialTasks, pendingDelete: null };
}

function removeIds(tasks: Task[], ids: string[] | undefined): Task[] {
  if (!ids || ids.length === 0) return tasks;
  return tasks.filter((task) => !ids.includes(task.id));
}

/**
 * Чиста функція: без HTTP, DOM, localStorage та таймерів.
 * Нове значення id / token приходить у payload, тому результат залежить лише від аргументів.
 * Завжди діє не більше одного активного Undoable Delete: новий запит
 * остаточно завершує попередній.
 */
export function taskReducer(state: TaskState, action: TaskAction): TaskState {
  switch (action.type) {
    case 'add':
      return { ...state, tasks: [action.payload, ...state.tasks] };

    case 'toggle':
      return {
        ...state,
        tasks: state.tasks.map((task) =>
          task.id === action.payload.id ? { ...task, completed: !task.completed } : task,
        ),
      };

    case 'update':
      return {
        ...state,
        tasks: state.tasks.map((task) =>
          task.id === action.payload.id ? { ...task, ...action.payload.changes } : task,
        ),
      };

    case 'requestDelete': {
      const tasks = removeIds(state.tasks, state.pendingDelete?.ids);
      if (!tasks.some((task) => task.id === action.payload.id)) return state;
      return { tasks, pendingDelete: { ids: [action.payload.id], token: action.payload.token } };
    }

    case 'confirmDelete': {
      const { pendingDelete } = state;
      if (!pendingDelete || pendingDelete.token !== action.payload.token) return state;
      return { tasks: removeIds(state.tasks, pendingDelete.ids), pendingDelete: null };
    }

    case 'undoDelete':
      return state.pendingDelete ? { ...state, pendingDelete: null } : state;

    case 'clearCompleted': {
      const tasks = removeIds(state.tasks, state.pendingDelete?.ids);
      const ids = tasks.filter((task) => task.completed).map((task) => task.id);
      if (ids.length === 0) return state;
      return { tasks, pendingDelete: { ids, token: action.payload.token } };
    }

    case 'reset':
      return { tasks: [...initialTasks], pendingDelete: null };

    default:
      return state;
  }
}
