import { useEffect } from 'react';
import './App.scss';
import { Actions } from './components/Actions';
import { FilterBar } from './components/FilterBar';
import { Stats } from './components/Stats';
import { TaskForm } from './components/TaskForm';
import { TaskList } from './components/TaskList';
import { ToastHost } from './components/Toast';
import { TaskProvider } from './context/TaskProvider';
import { useTaskContext } from './hooks/useTaskContext';

function Planner() {
  const { stats, editingTask } = useTaskContext();

  // Синхронізація React state із зовнішнім API браузера.
  useEffect(() => {
    document.title = `Study Planner — ${stats.active} active tasks`;
  }, [stats.active]);

  return (
    <main className="app">
      <header className="app__header">
        <h1 className="app__title">Study Planner</h1>
        <p className="app__subtitle">Плануйте навчання та не губіть завдання.</p>
      </header>

      <div className="app__section">
        <Stats />
      </div>
      <div className="app__section">
        <TaskForm key={editingTask?.id ?? 'new'} />
      </div>
      <div className="app__section">
        <FilterBar />
      </div>
      <div className="app__section">
        <TaskList />
      </div>
      <Actions />
      <ToastHost />
    </main>
  );
}

export default function App() {
  return (
    <TaskProvider>
      <Planner />
    </TaskProvider>
  );
}
