import type { Task } from '../types/task';

export const initialTasks: Task[] = [
  {
    id: 'seed-1',
    title: 'Опрацювати Context API',
    description: 'Прочитати розділи Sharing State та Scaling Up with Reducer and Context.',
    priority: 'high',
    category: 'study',
    completed: false,
    createdAt: 1,
  },
  {
    id: 'seed-2',
    title: 'Здати лабораторну №9',
    description: 'useReducer, Context, localStorage та Undoable Delete.',
    priority: 'high',
    category: 'lab',
    completed: false,
    createdAt: 2,
  },
  {
    id: 'seed-3',
    title: 'Повторити useEffect',
    description: 'Cleanup, залежності та синхронізація із зовнішніми системами.',
    priority: 'medium',
    category: 'study',
    completed: true,
    createdAt: 3,
  },
  {
    id: 'seed-4',
    title: 'Оновити README проєкту',
    description: '',
    priority: 'low',
    category: 'project',
    completed: false,
    createdAt: 4,
  },
];
