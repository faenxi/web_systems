import { TASKS_STORAGE_KEY } from './constants';
import { CATEGORIES, PRIORITIES } from './labels';
import type { Category, Priority, Task } from '../types/task';

function isTask(value: unknown): value is Task {
  if (typeof value !== 'object' || value === null) return false;
  const t = value as Record<string, unknown>;
  return (
    typeof t.id === 'string' &&
    typeof t.title === 'string' &&
    typeof t.description === 'string' &&
    typeof t.completed === 'boolean' &&
    typeof t.createdAt === 'number' &&
    PRIORITIES.includes(t.priority as Priority) &&
    CATEGORIES.includes(t.category as Category)
  );
}

/** Читає збережені завдання. Повертає null, якщо даних немає або вони пошкоджені. */
export function loadStoredTasks(): Task[] | null {
  try {
    const raw = window.localStorage.getItem(TASKS_STORAGE_KEY);
    if (raw === null) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.every(isTask)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveTasks(tasks: Task[]): void {
  try {
    window.localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
  } catch {
    // сховище недоступне або переповнене — застосунок продовжує працювати в пам'яті
  }
}
