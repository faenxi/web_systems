import { createContext } from 'react';
import type { Filter, PendingDelete, Task, TaskDraft, TaskStats } from '../types/task';
import type { ToastMessage } from '../types/toast';

export interface TaskContextValue {
  tasks: Task[];
  visibleTasks: Task[];
  stats: TaskStats;
  filter: Filter;
  setFilter: (filter: Filter) => void;
  pendingDelete: PendingDelete | null;
  isPendingDelete: (id: string) => boolean;
  editingTask: Task | null;
  startEdit: (id: string) => void;
  cancelEdit: () => void;
  addTask: (draft: TaskDraft) => boolean;
  updateTask: (id: string, draft: TaskDraft) => boolean;
  toggleTask: (id: string) => void;
  requestDelete: (id: string) => void;
  undoDelete: () => void;
  clearCompleted: () => void;
  resetTasks: () => void;
  toast: ToastMessage | null;
}

export const TaskContext = createContext<TaskContextValue | null>(null);
