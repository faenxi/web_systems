import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { TaskContext } from './TaskContext';
import type { TaskContextValue } from './TaskContext';
import { FILTER_STORAGE_KEY, TOAST_DURATION_MS, UNDO_DELAY_MS } from '../data/constants';
import { FILTERS } from '../data/labels';
import { saveTasks } from '../data/storage';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { initTaskState, taskReducer } from '../reducers/taskReducer';
import type { Filter, TaskDraft } from '../types/task';
import type { ToastKind, ToastMessage } from '../types/toast';
import { createId } from '../utils/cx';

const isFilter = (value: unknown): value is Filter => FILTERS.includes(value as Filter);

export function TaskProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(taskReducer, undefined, initTaskState);
  const [filter, setFilter] = useLocalStorage<Filter>(FILTER_STORAGE_KEY, 'all', isFilter);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const toastCounter = useRef(0);

  const { tasks, pendingDelete } = state;

  const notify = useCallback((message: string, kind: ToastKind = 'success') => {
    toastCounter.current += 1;
    setToast({ id: toastCounter.current, message, kind });
  }, []);

  // Effect 1: синхронізація tasks з localStorage (reducer лишається джерелом правди).
  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  // Effect 2: таймер Undoable Delete. Reducer лише змінює state, а таймер живе тут.
  const pendingToken = pendingDelete?.token;
  const pendingCount = pendingDelete?.ids.length ?? 0;
  useEffect(() => {
    if (pendingToken === undefined) return;
    const timerId = window.setTimeout(() => {
      dispatch({ type: 'confirmDelete', payload: { token: pendingToken } });
      notify(
        pendingCount === 1 ? 'Завдання остаточно видалено' : `Остаточно видалено завдань: ${pendingCount}`,
      );
    }, UNDO_DELAY_MS);
    return () => window.clearTimeout(timerId);
  }, [pendingToken, pendingCount, notify]);

  // Effect 3: автоматичне зникнення звичайного Toast.
  useEffect(() => {
    if (toast === null) return;
    const timerId = window.setTimeout(() => setToast(null), TOAST_DURATION_MS);
    return () => window.clearTimeout(timerId);
  }, [toast]);

  const isPendingDelete = useCallback(
    (id: string) => pendingDelete?.ids.includes(id) ?? false,
    [pendingDelete],
  );

  // Derived state: обчислюється під час render, а не в Effect.
  const stats = useMemo(() => {
    const live = tasks.filter((task) => !pendingDelete?.ids.includes(task.id));
    const completed = live.filter((task) => task.completed).length;
    return { total: live.length, completed, active: live.length - completed };
  }, [tasks, pendingDelete]);

  const visibleTasks = useMemo(() => {
    if (filter === 'active') return tasks.filter((task) => !task.completed);
    if (filter === 'completed') return tasks.filter((task) => task.completed);
    return tasks;
  }, [tasks, filter]);

  const editingTask = useMemo(
    () => tasks.find((task) => task.id === editingId) ?? null,
    [tasks, editingId],
  );

  const addTask = useCallback(
    (draft: TaskDraft) => {
      if (draft.title.trim() === '') {
        notify('Вкажіть назву завдання', 'error');
        return false;
      }
      dispatch({
        type: 'add',
        payload: { ...draft, id: createId(), completed: false, createdAt: Date.now() },
      });
      notify('Завдання створено');
      return true;
    },
    [notify],
  );

  const updateTask = useCallback(
    (id: string, draft: TaskDraft) => {
      if (draft.title.trim() === '') {
        notify('Назва завдання не може бути порожньою', 'error');
        return false;
      }
      dispatch({ type: 'update', payload: { id, changes: draft } });
      setEditingId(null);
      notify('Зміни збережено');
      return true;
    },
    [notify],
  );

  const toggleTask = useCallback(
    (id: string) => {
      if (pendingDelete?.ids.includes(id)) {
        notify('Завдання очікує видалення — скасуйте видалення, щоб його змінити', 'error');
        return;
      }
      dispatch({ type: 'toggle', payload: { id } });
    },
    [pendingDelete, notify],
  );

  const startEdit = useCallback(
    (id: string) => {
      if (pendingDelete?.ids.includes(id)) {
        notify('Завдання очікує видалення — його не можна редагувати', 'error');
        return;
      }
      setEditingId(id);
    },
    [pendingDelete, notify],
  );

  const cancelEdit = useCallback(() => setEditingId(null), []);

  const requestDelete = useCallback(
    (id: string) => {
      if (editingId === id) setEditingId(null);
      dispatch({ type: 'requestDelete', payload: { id, token: Date.now() } });
    },
    [editingId],
  );

  const undoDelete = useCallback(() => dispatch({ type: 'undoDelete' }), []);

  const clearCompleted = useCallback(() => {
    const completed = tasks.filter((task) => task.completed && !pendingDelete?.ids.includes(task.id));
    if (completed.length === 0) {
      notify('Немає виконаних завдань для очищення', 'error');
      return;
    }
    if (completed.some((task) => task.id === editingId)) setEditingId(null);
    dispatch({ type: 'clearCompleted', payload: { token: Date.now() } });
  }, [tasks, pendingDelete, editingId, notify]);

  const resetTasks = useCallback(() => {
    setEditingId(null);
    dispatch({ type: 'reset' });
    notify('Дані скинуто до початкових');
  }, [notify]);

  const value = useMemo<TaskContextValue>(
    () => ({
      tasks,
      visibleTasks,
      stats,
      filter,
      setFilter,
      pendingDelete,
      isPendingDelete,
      editingTask,
      startEdit,
      cancelEdit,
      addTask,
      updateTask,
      toggleTask,
      requestDelete,
      undoDelete,
      clearCompleted,
      resetTasks,
      toast,
    }),
    [
      tasks, visibleTasks, stats, filter, setFilter, pendingDelete, isPendingDelete, editingTask,
      startEdit, cancelEdit, addTask, updateTask, toggleTask, requestDelete, undoDelete,
      clearCompleted, resetTasks, toast,
    ],
  );

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
}
