import './Actions.scss';
import { useTaskContext } from '../hooks/useTaskContext';

export function Actions() {
  const { clearCompleted, resetTasks } = useTaskContext();

  const handleReset = () => {
    if (window.confirm('Скинути всі дані до початкових? Ваші завдання буде втрачено.')) {
      resetTasks();
    }
  };

  return (
    <div className="actions">
      <button className="actions__button" type="button" onClick={clearCompleted}>
        Очистити виконані
      </button>
      <button className="actions__button actions__button--danger" type="button" onClick={handleReset}>
        Скинути дані
      </button>
    </div>
  );
}
