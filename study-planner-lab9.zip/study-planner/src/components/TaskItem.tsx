import './TaskItem.scss';
import { CATEGORY_LABELS, PRIORITY_LABELS } from '../data/labels';
import { useTaskContext } from '../hooks/useTaskContext';
import type { Task } from '../types/task';
import { cx } from '../utils/cx';

export function TaskItem({ task }: { task: Task }) {
  const { toggleTask, startEdit, requestDelete, isPendingDelete } = useTaskContext();
  const pending = isPendingDelete(task.id);

  return (
    <li
      className={cx(
        'task-item',
        `task-item--${task.priority}`,
        task.completed && 'task-item--completed',
        pending && 'task-item--pending',
      )}
    >
      <input
        className="task-item__checkbox"
        type="checkbox"
        checked={task.completed}
        onChange={() => toggleTask(task.id)}
        aria-label={`Виконано: ${task.title}`}
      />
      <div>
        <h3 className="task-item__title">{task.title}</h3>
        {task.description && <p className="task-item__description">{task.description}</p>}
        <div className="task-item__meta">
          <span className="task-item__badge">{PRIORITY_LABELS[task.priority]}</span>
          <span className="task-item__badge">{CATEGORY_LABELS[task.category]}</span>
          {pending && <span className="task-item__badge task-item__badge--pending">Буде видалено</span>}
        </div>
      </div>
      <div className="task-item__actions">
        <button className="task-item__button" type="button" onClick={() => startEdit(task.id)}>
          Редагувати
        </button>
        <button
          className="task-item__button task-item__button--danger"
          type="button"
          onClick={() => requestDelete(task.id)}
          disabled={pending}
        >
          Видалити
        </button>
      </div>
    </li>
  );
}
