import './FilterBar.scss';
import { FILTERS, FILTER_LABELS } from '../data/labels';
import { useTaskContext } from '../hooks/useTaskContext';
import { cx } from '../utils/cx';

export function FilterBar() {
  const { filter, setFilter } = useTaskContext();

  return (
    <div className="filter-bar" role="group" aria-label="Фільтр завдань">
      {FILTERS.map((item) => (
        <button
          key={item}
          type="button"
          className={cx('filter-bar__button', filter === item && 'filter-bar__button--active')}
          aria-pressed={filter === item}
          onClick={() => setFilter(item)}
        >
          {FILTER_LABELS[item]}
        </button>
      ))}
    </div>
  );
}
