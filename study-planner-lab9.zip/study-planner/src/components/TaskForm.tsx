import { useState } from 'react';
import type { FormEvent } from 'react';
import './TaskForm.scss';
import { CATEGORIES, CATEGORY_LABELS, PRIORITIES, PRIORITY_LABELS } from '../data/labels';
import { useTaskContext } from '../hooks/useTaskContext';
import type { Category, Priority } from '../types/task';
import { cx } from '../utils/cx';

/** Форма створення та редагування. Початкові значення беруться з editingTask (key у App перемонтовує форму). */
export function TaskForm() {
  const { editingTask, addTask, updateTask, cancelEdit } = useTaskContext();
  const [title, setTitle] = useState(editingTask?.title ?? '');
  const [description, setDescription] = useState(editingTask?.description ?? '');
  const [priority, setPriority] = useState<Priority>(editingTask?.priority ?? 'medium');
  const [category, setCategory] = useState<Category>(editingTask?.category ?? 'study');

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const draft = { title: title.trim(), description: description.trim(), priority, category };
    if (editingTask) {
      updateTask(editingTask.id, draft);
      return;
    }
    if (addTask(draft)) {
      setTitle('');
      setDescription('');
      setPriority('medium');
      setCategory('study');
    }
  };

  return (
    <form
      className={cx('task-form', editingTask && 'task-form--editing')}
      onSubmit={handleSubmit}
      noValidate
    >
      <h2 className="task-form__title">{editingTask ? 'Редагування завдання' : 'Нове завдання'}</h2>

      <label className="task-form__field">
        <span className="task-form__label">Назва</span>
        <input
          className="task-form__input"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Наприклад, підготуватися до заліку"
        />
      </label>

      <label className="task-form__field">
        <span className="task-form__label">Опис</span>
        <textarea
          className="task-form__textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </label>

      <div className="task-form__row">
        <label className="task-form__field">
          <span className="task-form__label">Пріоритет</span>
          <select
            className="task-form__input"
            value={priority}
            onChange={(e) => setPriority(e.target.value as Priority)}
          >
            {PRIORITIES.map((p) => (
              <option key={p} value={p}>
                {PRIORITY_LABELS[p]}
              </option>
            ))}
          </select>
        </label>
        <label className="task-form__field">
          <span className="task-form__label">Категорія</span>
          <select
            className="task-form__input"
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {CATEGORY_LABELS[c]}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="task-form__actions">
        <button className="task-form__submit" type="submit">
          {editingTask ? 'Зберегти зміни' : 'Додати завдання'}
        </button>
        {editingTask && (
          <button className="task-form__cancel" type="button" onClick={cancelEdit}>
            Скасувати
          </button>
        )}
      </div>
    </form>
  );
}
