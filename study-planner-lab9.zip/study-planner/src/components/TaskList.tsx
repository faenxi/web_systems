import './TaskList.scss';
import { TaskItem } from './TaskItem';
import { useTaskContext } from '../hooks/useTaskContext';
import type { Filter } from '../types/task';

const EMPTY_MESSAGES: Record<Filter, string> = {
  all: 'Список порожній. Додайте перше завдання.',
  active: 'Невиконаних завдань немає.',
  completed: 'Виконаних завдань поки немає.',
};

export function TaskList() {
  const { visibleTasks, filter } = useTaskContext();

  if (visibleTasks.length === 0) {
    return <p className="task-list__empty">{EMPTY_MESSAGES[filter]}</p>;
  }

  return (
    <ul className="task-list">
      {visibleTasks.map((task) => (
        <TaskItem key={task.id} task={task} />
      ))}
    </ul>
  );
}
