import './Toast.scss';
import { UNDO_DELAY_MS } from '../data/constants';
import { useTaskContext } from '../hooks/useTaskContext';
import type { ToastKind } from '../types/toast';
import { cx } from '../utils/cx';

interface ToastProps {
  message: string;
  kind: ToastKind;
  /** Якщо задано — показується смужка прогресу такої тривалості. */
  progressMs?: number;
  actionLabel?: string;
  onAction?: () => void;
}

export function Toast({ message, kind, progressMs, actionLabel, onAction }: ToastProps) {
  return (
    <div className={cx('toast', `toast--${kind}`, progressMs !== undefined && 'toast--undo')}>
      <span className="toast__message">{message}</span>
      {actionLabel && (
        <button className="toast__action" type="button" onClick={onAction}>
          {actionLabel}
        </button>
      )}
      {progressMs !== undefined && (
        <span className="toast__progress" style={{ animationDuration: `${progressMs}ms` }} />
      )}
    </div>
  );
}

/** Показує Toast Undoable Delete (з таймером) та звичайний Toast зворотного зв'язку. */
export function ToastHost() {
  const { toast, pendingDelete, tasks, undoDelete } = useTaskContext();

  let pendingMessage = '';
  if (pendingDelete) {
    const count = pendingDelete.ids.length;
    const title = tasks.find((task) => task.id === pendingDelete.ids[0])?.title;
    pendingMessage =
      count === 1 ? `Завдання «${title}» буде видалено` : `Виконані завдання (${count}) буде видалено`;
  }

  return (
    <div className="toast-host" role="status" aria-live="polite">
      {pendingDelete && (
        <Toast
          key={pendingDelete.token}
          message={pendingMessage}
          kind="success"
          progressMs={UNDO_DELAY_MS}
          actionLabel="Скасувати"
          onAction={undoDelete}
        />
      )}
      {toast && <Toast key={toast.id} message={toast.message} kind={toast.kind} />}
    </div>
  );
}
