import './Stats.scss';
import { useTaskContext } from '../hooks/useTaskContext';

export function Stats() {
  const { stats } = useTaskContext();

  return (
    <dl className="stats" aria-label="Статистика">
      <div className="stats__item">
        <dt className="stats__label">Усього</dt>
        <dd className="stats__value">{stats.total}</dd>
      </div>
      <div className="stats__item stats__item--accent">
        <dt className="stats__label">Активні</dt>
        <dd className="stats__value">{stats.active}</dd>
      </div>
      <div className="stats__item">
        <dt className="stats__label">Виконані</dt>
        <dd className="stats__value">{stats.completed}</dd>
      </div>
    </dl>
  );
}
