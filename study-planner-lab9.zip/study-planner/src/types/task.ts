export type Priority = 'low' | 'medium' | 'high';
export type Category = 'study' | 'lab' | 'project' | 'other';
export type Filter = 'all' | 'active' | 'completed';

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: Priority;
  category: Category;
  completed: boolean;
  createdAt: number;
}

/** Поля, які користувач може змінити у формі (створення / редагування). */
export type TaskDraft = Pick<Task, 'title' | 'description' | 'priority' | 'category'>;

/** Завдання, що очікують остаточного видалення (Undoable Delete). */
export interface PendingDelete {
  ids: string[];
  /** Унікальна мітка запиту — за нею Effect запускає та скидає таймер. */
  token: number;
}

export interface TaskState {
  tasks: Task[];
  pendingDelete: PendingDelete | null;
}

export type TaskAction =
  | { type: 'add'; payload: Task }
  | { type: 'toggle'; payload: { id: string } }
  | { type: 'update'; payload: { id: string; changes: TaskDraft } }
  | { type: 'requestDelete'; payload: { id: string; token: number } }
  | { type: 'confirmDelete'; payload: { token: number } }
  | { type: 'undoDelete' }
  | { type: 'clearCompleted'; payload: { token: number } }
  | { type: 'reset' };

export interface TaskStats {
  total: number;
  active: number;
  completed: number;
}
