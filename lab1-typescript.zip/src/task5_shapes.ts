// ==== Завдання 5: shapes.ts ====

interface Shape {
  getArea(): number;
  getPerimeter(): number;
}

class Circle implements Shape {
  constructor(private radius: number) {}

  getArea(): number {
    return Math.PI * this.radius ** 2;
  }

  getPerimeter(): number {
    return 2 * Math.PI * this.radius;
  }

  // масштабування - множимо розмір на коефіцієнт
  scale(factor: number): void {
    this.radius *= factor;
  }
}

class Rectangle implements Shape {
  constructor(private width: number, private height: number) {}

  getArea(): number {
    return this.width * this.height;
  }

  getPerimeter(): number {
    return 2 * (this.width + this.height);
  }

  scale(factor: number): void {
    this.width *= factor;
    this.height *= factor;
  }
}

class Triangle implements Shape {
  constructor(private a: number, private b: number, private c: number) {}

  // формула Герона для площі трикутника за трьома сторонами
  getArea(): number {
    const s = (this.a + this.b + this.c) / 2;
    return Math.sqrt(s * (s - this.a) * (s - this.b) * (s - this.c));
  }

  getPerimeter(): number {
    return this.a + this.b + this.c;
  }

  scale(factor: number): void {
    this.a *= factor;
    this.b *= factor;
    this.c *= factor;
  }
}

// Масив об'єктів типу Shape - завдяки інтерфейсу всі фігури можна тримати разом
const shapes: Shape[] = [
  new Circle(5),
  new Rectangle(4, 6),
  new Triangle(3, 4, 5),
];

let totalArea = 0;
let totalPerimeter = 0;

for (const shape of shapes) {
  totalArea += shape.getArea();
  totalPerimeter += shape.getPerimeter();
}

console.log(`Загальна площа усіх фігур: ${totalArea.toFixed(2)}`);
console.log(`Загальний периметр усіх фігур: ${totalPerimeter.toFixed(2)}`);
