export interface Participant {
  id: string
  name: string
  birthDate: string // yyyy-mm-dd
  email: string
  phone: string
}

export type ParticipantInput = Omit<Participant, 'id'>

export type FieldStatus = 'none' | 'valid' | 'invalid'
export type SortKey = 'name' | 'birthDate'
export type SortDirection = 'asc' | 'desc'
