import { useContext } from 'react';
import { ToastContext } from '../context/ToastContext';

export function useToast() {
  const context = useContext(ToastContext);
  if (context === null) {
    throw new Error('useToast має використовуватися всередині <ToastProvider>.');
  }
  return context;
}
